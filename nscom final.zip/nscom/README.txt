Instructions:
1. Open wireshark and choose "Adapter for Loopback traffic capture"
    >filter accordingly:
        ip.addr == 127.0.0.1 (for all traffic locally)
        RTCP || udp.port == 4001 (for RTCP usage)
        sip (focus on sip)


2. Open two separate terminals

3. Compile both files
    >javac SIPClient2.java SIPClient1.java

4. Run in this order:
    > java SIPClient2
    > java SIPClient1


Features:
- SIP HANDSHAKE
- SDP Negotiation
- RTP Packet Generation
- RTP Receiving and Playback
- RTCP Usage
- Call Teardown
- Documentation and Clarity
